
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;

namespace TestProject
{
    [TestClass]
    public class UnitTest
    {   
        public UnitTest()
        {
        }


        [TestMethod]
        public void Dms2Dec()
        {
            // Test Value
            Assert.AreEqual(1, LatLong.DMS2Dec("1", "0", "0", "N"));
            Assert.AreEqual(2, LatLong.DMS2Dec("1", "30", "1800", "N"));
            Assert.AreEqual(2, LatLong.DMS2Dec("1", "30", "1800", "W"));
            Assert.AreEqual(-2, LatLong.DMS2Dec("1", "30", "1800", "S"));
            Assert.AreEqual(-2, LatLong.DMS2Dec("1", "30", "1800", "E"));
            Assert.AreEqual(2, LatLong.DMS2Dec("1", "30", "1800", "n"));
            Assert.AreEqual(2, LatLong.DMS2Dec("1", "30", "1800", "w"));
            Assert.AreEqual(-2, LatLong.DMS2Dec("1", "30", "1800", "s"));
            Assert.AreEqual(-2, LatLong.DMS2Dec("1", "30", "1800", "e"));

            // Test wrong emisphere
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("1", "30", "1800", "r"));

            // Test wrong value
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("-1", "30", "1800", "n"));
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("1", "-30", "1800", "n"));
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("1", "30", "-1800", "n"));
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("999", "30", "1800", "n"));
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("1", "999", "1800", "n"));
            Assert.ThrowsException<Exception>(() => LatLong.DMS2Dec("1", "30", "9999", "n"));
            //Test letter instead values
            Assert.ThrowsException<FormatException>(() => LatLong.DMS2Dec("aa", "30", "1800", "n"));
            Assert.ThrowsException<FormatException>(() => LatLong.DMS2Dec("1", "aa", "1800", "n"));
            Assert.ThrowsException<FormatException>(() => LatLong.DMS2Dec("1", "30", "aa", "n"));
        }
    }

}