// Example for a C# function that is called by a MapForce mapping
// If you make changes to this file, rebuild the included solution with Visual Studio.

using System;

public class LatLong
    // Class holding the static methods for the location transformation.
{
    static public decimal DMS2Dec(string degree, string minutes, string seconds, string hemisphere)
        // Transform a location expressed in Degree Minutes Second (DMS) in one expressed as decimal value
        // All the imput are Sting to avoid type issues in MapForce
    {
        float d = float.Parse(degree);
        float m = float.Parse(minutes);
        float s = float.Parse(seconds);
        float coordinate;

        if (d < 0 || d > 90) throw new  Exception("Invalid input degree value '" + d + "'");
        if (m < 0 || m > 60) throw new Exception("Invalid input minutes value '" + m + "'");
        if (s < 0 || s > 3600) throw new Exception("Invalid input seconds value '" + s + "'");

        coordinate = d + (m / 60) + (s / 3600);

        switch (hemisphere.ToLower().Trim())
        {
            case "n":
            case "w":
                return (decimal)coordinate;
            case "s":
            case "e":
                return (decimal)(-coordinate);
            default:
                throw new Exception("Invalid hemisphere "+ hemisphere+" indicated.");
        }
    }

}
